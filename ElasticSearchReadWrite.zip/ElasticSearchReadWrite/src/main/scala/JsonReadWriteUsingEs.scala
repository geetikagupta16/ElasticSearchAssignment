import java.io.{PrintWriter, File}
import java.net.InetAddress

import org.elasticsearch.action.bulk.BulkResponse
import org.elasticsearch.action.get.{MultiGetResponse, MultiGetItemResponse, GetResponse}
import org.elasticsearch.client.Client
import org.elasticsearch.client.transport.TransportClient
import org.elasticsearch.common.settings.Settings
import org.elasticsearch.common.transport.InetSocketTransportAddress

import scala.io.Source

/**
  * Created by knoldus on 3/4/16.
  */
class JsonReadWriteUsingEs {

  def getClient(): Client = {

    val settings: Settings = Settings.settingsBuilder()
      .put("cluster.name", "geetika").build()
    val client: Client = TransportClient.builder().settings(settings).build()
      .addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("localhost"), 9300))

    client
  }

  def insertBulkDocument(client: Client): BulkResponse = {
    val bulkJson = Source.fromFile("/home/knoldus/ElasticSearchAsgQuestion/inputJson.json").getLines().toList
    val bulkRequest = client.prepareBulk()
    for (i <- 0 until bulkJson.size) {
      bulkRequest.add(client.prepareIndex("jsonindex", "data", (i + 1).toString).setSource(bulkJson(i)))
    }
    bulkRequest.execute().actionGet()
  }

  def writeToFile(client: Client) = {
    val writer = new PrintWriter(new File("/home/knoldus/test.json"))


    val multiGetItemResponses: MultiGetResponse = client.prepareMultiGet().add("jsonindex", "data")
      .get()
    /*val getResponseIterator = multiGetItemResponses.iterator()
    while (getResponseIterator.hasNext) {

      println(getResponseIterator.next.getResponse.getSourceAsString)
      }
*/
    for (itemResponse: MultiGetItemResponse <- multiGetItemResponses) {
      val response: GetResponse = itemResponse.getResponse()
      if (response.isExists()) {
        val json = response.getSourceAsString()
        writer.write(json)
      }
    }
  }


}

object Jsondata extends App {

  val jsonrw = new JsonReadWriteUsingEs
  val client = jsonrw.getClient()
  val data = jsonrw.insertBulkDocument(client)
  println(data.getItems)

  val writeFile = jsonrw.writeToFile(client)

}
